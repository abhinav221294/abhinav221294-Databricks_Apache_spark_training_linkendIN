# Databricks notebook source
# MAGIC %fs 
# MAGIC mkdirs /FileStore/nyc_taxi_trips

# COMMAND ----------

# MAGIC %fs
# MAGIC cp https://github.com/MicrosoftLearning/mslearn-databricks/raw/main/data/yellow_tripdata_2021-01.parquet /FileStores/nyc_taxi_trips/yellow_tripdata_2021-01.parquet

# COMMAND ----------

dbutils.fs.cp("https://github.com/MicrosoftLearning/mslearn-databricks/raw/main/data/yellow_tripdata_2021-01.parquet", "/FileStore/nyc_taxi_trips/yellow_tripdata_2021-01.parquet")

# COMMAND ----------

df = (spark.readStream
          .format("cloudFiles")
          .option("cloudFiles.format", "parquet")
          .option("cloudFiles.schemaLocation", "/stream_data/nyc_taxi_trips/schema")
          .load("/FileStore/nyc_taxi_trips"))
df.writeStream.format("delta") \
      .option("checkpointLocation", "/stream_data/nyc_taxi_trips/checkpoints") \
      .option("mergeSchema", "true") \
      .start("/delta/nyc_taxi_trips")
display(df)

# COMMAND ----------

dbutils.fs.rm("/FileStore/nyc_taxi_trips/",True)
dbutils.fs.mkdirs("/FileStore/nyc_taxi_trips/")
dbutils.fs.cp("https://github.com/MicrosoftLearning/mslearn-databricks/raw/main/data/yellow_tripdata_2021-02_edited.parquet", "/FileStore/nyc_taxi_trips/yellow_tripdata_2021-02_edited.parquet")

# COMMAND ----------

df = spark.read.parquet("/FileStore/nyc_taxi_trips/yellow_tripdata_2021-02_edited.parquet")
#display(df)
location_counts = df.groupBy("PULocationID").count().orderBy("count", ascending=True)
location_counts.show(100)

# COMMAND ----------

## - Create salt column
from pyspark.sql.functions import lit, rand
# convert streaming Dataframe back to batch Dataframe
df = spark.read.parquet("/FileStore/nyc_taxi_trips/*.parquet")

# add a salt column
df_salted = df.withColumn("salt", (rand()*100).cast("int"))
# repartition based on salted column
df_salted.repartition("salt").write.mode("overwrite").format("parquet").save("delta/nyc_taxi_trips_salted")
display(df_salted)

# COMMAND ----------

# View the data file group by salt column
df = spark.read.parquet("/delta/nyc_taxi_trips_salted/*.parquet")
#display(df)
location_counts = df.groupBy("salt").count().orderBy("count", ascending=False)
location_counts.show(100)

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

