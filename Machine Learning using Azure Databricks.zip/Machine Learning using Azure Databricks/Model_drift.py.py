# Databricks notebook source
import mlflow
# Obtain the modelpath from the last experiment
modelpath = "dbfs:/databricks/mlflow-tracking/4419161495957088/f36948edd5754e809340e65fe664852f/artifacts/classifier-1754474608.0734057"
loaded_model = mlflow.spark.load_model(modelpath)

# COMMAND ----------

import pandas as pd
# /dbfs/FileStore/mlflow_lab/penguins.csv
penguins_df = pd.read_csv('/dbfs/FileStore/ml_lab/penguins.csv')
penguins_clean = penguins_df.dropna()
display(penguins_clean,limit=10)

# COMMAND ----------

def simulate_climate_drift(df, drift_intensity=0.3):
    """Simulate climate change effects on penguin measurements"""
    drifted_df = df.copy()
    
    # Climate change effects (Species: 0=Adelie, 1=Chinstrap, 2=Gentoo):
    # 1. Adelie penguins (Species=0) getting smaller (food scarcity)
    adelie_mask = drifted_df['Species'] == 0
    drifted_df.loc[adelie_mask, 'BodyMass'] *= (1 - drift_intensity * 0.1)
    drifted_df.loc[adelie_mask, 'CulmenLength'] *= (1 - drift_intensity * 0.05)
    
    # 2. Gentoo penguins (Species=2) adapting with stronger flippers
    gentoo_mask = drifted_df['Species'] == 2
    drifted_df.loc[gentoo_mask, 'FlipperLength'] *= (1 + drift_intensity * 0.08)
    
    # 3. Overall population shift - fewer Chinstrap penguins (Species=1)
    chinstrap_mask = drifted_df['Species'] == 1
    chinstrap_sample = drifted_df[chinstrap_mask].sample(frac=1-drift_intensity*0.4, random_state=42)
    
    # Combine the shifted data
    final_df = pd.concat([
        drifted_df[adelie_mask],
        drifted_df[gentoo_mask], 
        chinstrap_sample
    ]).reset_index(drop=True)
    
    return final_df

# Create drifted "production" data
production_data = simulate_climate_drift(penguins_clean, drift_intensity=0.5)

print(f"Original data shape: {penguins_clean.shape}")
print(f"Production data shape: {production_data.shape}")

# COMMAND ----------

#Preapre data for drift detection 
# Feature columns (match the CSV structure)
feature_cols = ['Island','CulmenLength', 'CulmenDepth', 'FlipperLength', 'BodyMass']

# Original training features and labels
X_train = penguins_clean[feature_cols]
y_train = penguins_clean['Species']

# Production features and labels
X_prod = production_data[feature_cols]
y_prod = production_data['Species']

print("Data prepared for drift analysis")
print(f"Species distribution in training: {y_train.value_counts().sort_index()}")
print(f"Species distribution in production: {y_prod.value_counts().sort_index()}")

# COMMAND ----------

#---
from scipy.stats import ks_2samp
import warnings
warnings.filterwarnings('ignore')

def detect_data_drift(X_reference, X_current, threshold=0.05):
    """Detect drift using Kolmogorov-Smirnov test"""
    drift_results = {}
    
    for column in X_reference.columns:
        # Perform KS test
        ks_stat, p_value = ks_2samp(X_reference[column], X_current[column])
        
        # Determine if drift is significant
        is_drift = p_value < threshold
        
        drift_results[column] = {
            'ks_statistic': ks_stat,
            'p_value': p_value,
            'drift_detected': is_drift
        }
    
    return drift_results

# Detect drift
drift_results = detect_data_drift(X_train, X_prod)

# Display results
print("🔍 DRIFT DETECTION RESULTS:")
print("-" * 50)
for feature, results in drift_results.items():
    status = "🚨 DRIFT" if results['drift_detected'] else "✅ OK"
    print(f"{feature:<20} {status:<10} p-value: {results['p_value']:.4f}")

# COMMAND ----------

### --- 
import matplotlib.pyplot as plt# Create drift visualization

fig, axes = plt.subplots((len(feature_cols)+1) // 2, 2, figsize=(12, 8))
axes = axes.ravel()

for i, feature in enumerate(feature_cols):
    ax = axes[i]
    
    # Plot distributions
    ax.hist(X_train[feature], alpha=0.7, label='Training Data', bins=20, color='blue')
    ax.hist(X_prod[feature], alpha=0.7, label='Production Data', bins=20, color='red')
    
    # Add drift status
    drift_status = "DRIFT DETECTED" if drift_results[feature]['drift_detected'] else "NO DRIFT"
    ax.set_title(f'{feature}\n{drift_status}')
    ax.legend()

plt.tight_layout()
plt.show()

# COMMAND ----------

import pprint
# Convert pandas DataFrames to Spark DataFrames
spark_X_train = spark.createDataFrame(X_train)
spark_X_prod = spark.createDataFrame(X_prod)

# Use transform instead of predict for Spark models
train_predictions_df = loaded_model.transform(spark_X_train)
prod_predictions_df = loaded_model.transform(spark_X_prod)

#display(train_predictions_df,limit=10)
#display(prod_predictions_df,limit=10)

# Extract predictions (assuming prediction column is named 'prediction')
train_predictions = train_predictions_df.select('prediction').rdd.flatMap(lambda x: x).collect()
prod_predictions = prod_predictions_df.select('prediction').rdd.flatMap(lambda x: x).collect()

pprint.pprint(train_predictions)
pprint.pprint(prod_predictions)

# COMMAND ----------

#----- Check accuracy ---
from sklearn.metrics import accuracy_score# Calculate accuracy
train_predictions = train_predictions_df.select('prediction').toPandas()['prediction'].values
prod_predictions = prod_predictions_df.select('prediction').toPandas()['prediction'].values
train_accuracy = accuracy_score(y_train.values, train_predictions)
prod_accuracy = accuracy_score(y_prod.values, prod_predictions)
print(f"Training accuracy: {train_accuracy:.2f}")
print(f"Production accuracy: {prod_accuracy:.2f}")

# COMMAND ----------

#--- Training or no retraining --
def trigger_model_retraining(X_new, y_new, model_name, drift_threshold=0.05):
    """Simple retraining pipeline triggered by drift"""
    
    print("🔄 TRIGGERING MODEL RETRAINING...")
    
    # Simple retraining (in practice, use your full pipeline)
    from sklearn.ensemble import RandomForestClassifier
    
    # Retrain with new data
    new_model = RandomForestClassifier(n_estimators=100, random_state=42)
    new_model.fit(X_new.select_dtypes(include=["number"]), y_new)
    
    # Evaluate new model
    new_predictions = new_model.predict(X_new)
    new_accuracy = accuracy_score(y_new, new_predictions)
    
    # Log new model to MLflow
    with mlflow.start_run():
        mlflow.log_param("retrain_trigger", "drift_detected")
        mlflow.log_metric("accuracy", new_accuracy)
        mlflow.sklearn.log_model(new_model, "retrained_model")
        
        # Register new model version
        model_uri = mlflow.get_artifact_uri("retrained_model")
        mlflow.register_model(model_uri, model_name)
    
    print(f"✅ NEW MODEL TRAINED - Accuracy: {new_accuracy:.3f}")
    return new_model

# Check if retraining is needed
performance_drop = train_accuracy - prod_accuracy
if performance_drop > 0.02 or True:
    #retrained_model = trigger_model_retraining(X_prod, y_prod, model_name)
    #retrained_model = trigger_model_retraining(X_prod, y_prod, "penguins_classification-retrained")
    print("🎉 Model Needs Retraining!")
else:
    print("📋 No retraining needed - monitoring continues")

# COMMAND ----------

# ---- Another way ----
# Simple manual drift detection (no lakehouse monitoring needed)
from scipy.stats import ks_2samp
import pandas as pd

def simple_drift_detection(baseline_data, current_data, threshold=0.05):
    """Simple drift detection using statistical tests"""
    results = {}
    
    for column in baseline_data.columns:
        # Kolmogorov-Smirnov test
        ks_stat, p_value = ks_2samp(baseline_data[column], current_data[column])
        
        results[column] = {
            'drift_score': ks_stat,
            'p_value': p_value,
            'drift_detected': p_value < threshold
        }
    
    return results

# Use this instead of lakehouse monitoring
drift_results = simple_drift_detection(X_train, X_prod)

# Display results
for feature, result in drift_results.items():
    status = "🚨 DRIFT" if result['drift_detected'] else "✅ OK"
    print(f"{feature}: {status} (p-value: {result['p_value']:.4f})")

# COMMAND ----------

## accuracy stats ---
# First check what your actual performance drop is:
print(f"Training accuracy: {train_accuracy:.3f}")
print(f"Production accuracy: {prod_accuracy:.3f}")  
print(f"Performance drop: {performance_drop:.3f}")

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

