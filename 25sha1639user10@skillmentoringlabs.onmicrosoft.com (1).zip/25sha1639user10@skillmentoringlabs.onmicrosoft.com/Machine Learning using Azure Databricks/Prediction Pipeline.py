# Databricks notebook source
25
# --- Load the model and Run
26
from pyspark.ml.pipeline import PipelineModel
27
from pyspark.sql.functions import col
28
persistModel = PipelineModel.load("/models/penguins.models")
29
newData = spark.createDataFrame([{"Island":"Biscoe","CulmenLength":47.6,"CulmenDepth":14.5,"FlipperLength":215,"BodyMass":5400}])
30
predictions = persistModel.transform(newData)
31
display(predictions.select("Island","CulmenDepth","CulmenLength","FlipperLength","BodyMass",col("prediction").alias("PredictedSpecies")))

# COMMAND ----------

dbutils.fs.ls("/models/")