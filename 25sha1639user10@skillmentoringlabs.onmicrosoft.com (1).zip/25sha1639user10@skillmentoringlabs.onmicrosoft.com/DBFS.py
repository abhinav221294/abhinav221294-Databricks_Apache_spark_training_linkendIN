# Databricks notebook source
# MAGIC %md
# MAGIC Using Delta Lake for ACID/Time Travel

# COMMAND ----------

dbutils.fs.mkdirs("dbfs:/FileStore/delta_tables")

print("Created directories")
display(dbutils.fs.ls('/FileStore/'))

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

