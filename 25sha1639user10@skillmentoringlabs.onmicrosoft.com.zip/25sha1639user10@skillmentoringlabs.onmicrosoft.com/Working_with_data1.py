# Databricks notebook source
dbutils.fs.mkdirs('/spark_lab')

# COMMAND ----------

dbutils.fs.mkdirs('/FileStore/spark_lab')

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *


orderSchema = StructType([
  StructField('SalesOrderNumber', StringType()),
  StructField('SalesOrderLineNumber', IntegerType()),
  StructField('OrderDate', DateType()),
  StructField('CustomerName', StringType()),
  StructField('Email', StringType()),
  StructField('Item', StringType()),
  StructField('Quality', IntegerType()),
  StructField('Quantity', IntegerType()),
  StructField('UnitPrice', FloatType()),
  StructField('Tax', FloatType())
  ])
df = spark.read.format('csv').schema(orderSchema).load('/FileStore/spark_lab/*.csv')
display(df.limit(100))



# COMMAND ----------

#df  = spark.read.csv('/FileStore/spark_lab/*.csv', header=True, inferSchema=True)
#display(df.limit(100))

# COMMAND ----------

from pyspark.sql.functions import col

df = df.dropDuplicates()
display(df.limit(100))

# COMMAND ----------

duplicate_counts = df.groupBy('SalesOrderNumber').count().filter(col('count') > 1).count()

print("Number of duplicates orders ", str(duplicate_counts))

# COMMAND ----------

customers = df["CustomerName","Email"]
print(customers.count())
print(customers.distinct().count())
display(customers.distinct())

# COMMAND ----------

df.createOrReplaceTempView("salesorder")

# COMMAND ----------

# MAGIC %sql
# MAGIC Select *
# MAGIC from salesorder limit 10;

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

