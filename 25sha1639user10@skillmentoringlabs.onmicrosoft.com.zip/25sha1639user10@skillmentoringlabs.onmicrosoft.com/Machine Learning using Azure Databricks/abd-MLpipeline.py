# Databricks notebook source
# MAGIC %md
# MAGIC # Machine Learning using Azure Databricks
# MAGIC # Lab object 
# MAGIC # Dataset - Antarctic penguin observation 
# MAGIC # Goal : Predict the penguin species from physical feature
# MAGIC # Tools - Spark MLLib , Azure Databrics
# MAGIC # Outcome Production ready Ml pipeline
# MAGIC
# MAGIC

# COMMAND ----------

#1. Create a directory to hold the data files
#2. Download and copy the penguin data file from GitHub

dbutils.fs.mkdirs("/FileStore/ml_lab")
dbutils.fs.cp("https://raw.githubusercontent.com/MicrosoftLearning/mslearn-databricks/main/data/penguins.csv","/FileStore/ml_lab/penguins.csv")
#Check that the file was copied
dbutils.fs.ls("/FileStore/ml_lab")

# COMMAND ----------

df = spark.read.csv("/FileStore/ml_lab/penguins.csv", header=True, inferSchema=True)
display(df)

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *

#Add a column to the DataFrame with the species name as a string
# data cleaning & type conversion
data = df.dropna().select(col("Island").astype("string"),
                          col("CulmenLength").astype("float"),
                         col("CulmenDepth").astype("float"),
                         col("FlipperLength").astype("float"),
                         col("BodyMass").astype("float"),
                         col("Species").astype("int")
                         )
display(data)


# COMMAND ----------

# Data Splitting Training and Test
splits = data.randomSplit([0.7, 0.3])

train = splits[0]
test = splits[1]

print("Training set size: %d" % train.count())
print("Test set size: %d" % test.count())

# COMMAND ----------

from pyspark.ml.feature import StringIndexer
indexer = StringIndexer(inputCol="Island", outputCol="IslandIndex")
indexedData = indexer.fit(train).transform(train).drop("Island")
display(indexedData)

# COMMAND ----------

## feature engineering 
#from pyspark.ml.feature import StringIndexer
#
#indexer = StringIndexer().setInputCol("Island").setOutputCol("IslandIndex")
#indexerData = indexer.fit(train).transform(train).drop("Island")
#display(indexerData)

# COMMAND ----------

# feature Engineering 
# Create a feature vector from the columns
from pyspark.ml.feature import VectorAssembler, MinMaxScaler

# Create a vector column containing all numeric features
numericFeatures = ["CulmenLength", "CulmenDepth", "FlipperLength", "BodyMass"]
numericColVector = VectorAssembler(inputCols=numericFeatures, outputCol="numericFeatures")
vectorizedData = numericColVector.transform(indexedData)

# Use a MinMax scaler to normalize the numeric values in the vector
minMax = MinMaxScaler(inputCol = numericColVector.getOutputCol(), outputCol="normalizedFeatures")
scaledData = minMax.fit(vectorizedData).transform(vectorizedData)

# Display the data with numeric feature vectors (before and after scaling)
compareNumerics = scaledData.select("numericFeatures", "normalizedFeatures")
display(compareNumerics)

# COMMAND ----------

# final feature preparation
# combime all features

featVect = VectorAssembler(inputCols=["IslandIndex", "normalizedFeatures"], outputCol="featuresVector")
preppedData = featVect.transform(scaledData)[col("featuresVector").alias("features"), col("Species").alias("label")]
display(preppedData)

# COMMAND ----------

#Model Training
from pyspark.ml.classification import LogisticRegression
lr = LogisticRegression(labelCol="label",featuresCol="features",maxIter=10, regParam=0.3)
model= lr.fit(preppedData)
print("Model trained.")

# COMMAND ----------

#Correct approach - reuse fitted transformers
prediction = model.transform(preppedData)
predicted = prediction.select("features", "probability", col("prediction").astype("Int"), col("label").alias("trueLabel"))
display(predicted)
print("Model trained.")

# COMMAND ----------

from pyspark.ml.evaluation import MulticlassClassificationEvaluator

evaluator = MulticlassClassificationEvaluator(labelCol="label", predictionCol="prediction")

# Simple accuracy
accuracy = evaluator.evaluate(prediction, {evaluator.metricName:"accuracy"})
print("Accuracy:", accuracy)

# Individual class metrics
labels = [0,1,2]
print("\nIndividual class metrics:")
for label in sorted(labels):
   print ("Class %s" % (label))

   # Precision
   precision = evaluator.evaluate(prediction, {evaluator.metricLabel:label,
                                               evaluator.metricName:"precisionByLabel"})
   print("\tPrecision:", precision)

   # Recall
   recall = evaluator.evaluate(prediction, {evaluator.metricLabel:label,
                                            evaluator.metricName:"recallByLabel"})
   print("\tRecall:", recall)

   # F1 score
   f1 = evaluator.evaluate(prediction, {evaluator.metricLabel:label,
                                        evaluator.metricName:"fMeasureByLabel"})
   print("\tF1 Score:", f1)

# Weighted (overall) metrics
overallPrecision = evaluator.evaluate(prediction, {evaluator.metricName:"weightedPrecision"})
print("Overall Precision:", overallPrecision)
overallRecall = evaluator.evaluate(prediction, {evaluator.metricName:"weightedRecall"})
print("Overall Recall:", overallRecall)
overallF1 = evaluator.evaluate(prediction)

# COMMAND ----------

from pyspark.ml.stat import Correlation

# Assemble independent variables into a vector
independent_features = ["IslandIndex", "CulmenLength", "CulmenDepth", "FlipperLength", "BodyMass"]
assembler = VectorAssembler(inputCols=independent_features, outputCol="independentFeatures")
indep_data = assembler.transform(indexedData).select("independentFeatures")

# Compute Pearson correlation matrix
corr_matrix = Correlation.corr(indep_data, "independentFeatures", "pearson").head()[0]
display(spark.createDataFrame(corr_matrix.toArray().tolist(), independent_features))

# COMMAND ----------

# MAGIC %md
# MAGIC #Create the MLpipeline

# COMMAND ----------

import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd

numeric_cols = ["CulmenLength", "CulmenDepth", "FlipperLength", "BodyMass"]
pandas_df = data.select(numeric_cols).toPandas()
corr = pandas_df.corr()


plt.figure(figsize=(6, 4))
sns.heatmap(corr, annot=True, cmap="coolwarm", fmt=".2f")
plt.title("Correlation Matrix")
display()

# COMMAND ----------

from pyspark.ml import Pipeline
from pyspark.ml.feature import StringIndexer, VectorAssembler, MinMaxScaler
from pyspark.ml.classification import LogisticRegression

catFeature = "Island"
numFeatures = ["CulmenLength", "CulmenDepth", "FlipperLength", "BodyMass"]

# Define the feature engineering and model training algorithm steps
catIndexer = StringIndexer(inputCol=catFeature, outputCol=catFeature + "Idx")
numVector = VectorAssembler(inputCols=numFeatures, outputCol="numericFeatures")
numScaler = MinMaxScaler(inputCol = numVector.getOutputCol(), outputCol="normalizedFeatures")
featureVector = VectorAssembler(inputCols=["IslandIdx", "normalizedFeatures"], outputCol="Features")
algo = LogisticRegression(labelCol="Species", featuresCol="Features", maxIter=10, regParam=0.3)

# Chain the steps as stages in a pipeline
pipeline = Pipeline(stages=[catIndexer, numVector, numScaler, featureVector, algo])

# Use the pipeline to prepare data and fit the model algorithm
model = pipeline.fit(train)
print ("Model trained!")

# COMMAND ----------

from pyspark.ml import Pipeline
from pyspark.ml.feature import StringIndexer, VectorAssembler, MinMaxScaler
from pyspark.ml.classification import DecisionTreeClassifier

catFeature = "Island"
numFeatures = ["CulmenLength", "CulmenDepth", "FlipperLength", "BodyMass"]

# Define the feature engineering and model training algorithm steps
catIndexer = StringIndexer(inputCol=catFeature, outputCol=catFeature + "Idx")
numVector = VectorAssembler(inputCols=numFeatures, outputCol="numericFeatures")
numScaler = MinMaxScaler(inputCol = numVector.getOutputCol(), outputCol="normalizedFeatures")
featureVector = VectorAssembler(inputCols=["IslandIdx", "normalizedFeatures"], outputCol="Features")
algo = DecisionTreeClassifier(labelCol="Species", featuresCol="Features", maxDepth=10)

# Chain the steps as stages in a pipeline
pipeline = Pipeline(stages=[catIndexer, numVector, numScaler, featureVector, algo])

# Use the pipeline to prepare data and fit the model algorithm
model = pipeline.fit(train)
print ("Model trained!")

# COMMAND ----------



# COMMAND ----------

prediction = model.transform(test)
predicted = prediction.select("Features", "probability", col("prediction").astype("Int"), col("Species").alias("trueLabel"))
display(predicted)

# COMMAND ----------

model.write().overwrite().save('/models/penguins.models')

# COMMAND ----------

